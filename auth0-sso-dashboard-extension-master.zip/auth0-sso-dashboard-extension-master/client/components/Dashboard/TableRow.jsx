export default (props) => (
  <tr>
  { props.children }
  </tr>
);
