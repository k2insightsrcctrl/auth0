export default (props) => (
  <thead>
    <tr>
    { props.children }
    </tr>
  </thead>
);
