export default (props) => (
  <tbody>
  { props.children }
  </tbody>
);
